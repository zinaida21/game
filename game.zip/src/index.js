const text = 'Текст';
console.log(text);
