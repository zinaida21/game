//import functions from 'script.js';
//import './img/*.png';
import './style.css';
import './script.js';
//import './index.html';
