//const buttonsParent = document.querySelector('.level__buttons');
//const buttonsLevel = document.querySelectorAll('.level__button--num');
/*const level = document.querySelector('.level');
const buttonStart = document.querySelector('.level__button--start');

function levelSelection(event) {
    let target = event.target;
    let targetLevel = target.getAttribute('data-order');
    if (targetLevel === 1 && buttonStart.click) {
        level.style.display = 'none';
        lowLevel();
    }
    if (targetLevel === 2) {
        level.style.display = 'none';
        middleLevel();
    }
    if (targetLevel === 3) {
        level.style.display = 'none';
        highLevel();
    }
}

levelSelection();*/

/*buttonsParent.addEventListener('click', function (event) {
    let target = event.target;
    let targetLevel = target.getAttribute('data-order');
    console.log(target.getAttribute('data-order') + ' уровень');
    if (targetLevel === 1 ) {
        level.style.display = 'none';
        lowLevel();
    }
    if (targetLevel === 2) {
        level.style.display = 'none';
        middleLevel();
    }
    if (targetLevel === 3) {
        level.style.display = 'none';
        highLevel();
    }
});*/
/*
function lowLevel() {
    console.log('1 уровень');
}

function middleLevel() {
    console.log('2 уровень');
}

function highLevel() {
    console.log('3 уровень');
}
*/
